namespace MongoDB;

public interface IDatabaseService
{
    void Connect();
    //dddd
}