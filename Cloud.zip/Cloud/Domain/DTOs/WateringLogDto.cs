﻿namespace Domain.DTOs;

public class WateringLogDto
{
    public DateTime WateringTime { get; set; }
    public int QuantityML { get; set; }
}