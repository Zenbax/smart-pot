using Domain.Model;

namespace Domain.DTOs;

public class PlantGetAllDto
{
    public ICollection<Plant> Plants { get; set; }
    public string Message { get; set; }
    public bool Success { get; set; }
}