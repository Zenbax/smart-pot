﻿using System.ComponentModel.DataAnnotations;
using Domain.Model;

namespace Domain.DTOs;

public class UserGetAllDto
{
    public ICollection<User> Users { get; set; }
    public string Message { get; set; }
    public bool Success { get; set; }
    
}