namespace Domain.DTOs;

public class PotDeleteDto
{
    public PotDeleteDto(string idToDelete)
    {
        IdToDelete = idToDelete;
    }
    
    public PotDeleteDto()
    {
    }

    public string IdToDelete { get; set; }
    public string Message { get; set; }
    public bool Success { get; set; }
}