using Domain.Model;
using YourApiNamespace.Controllers;

namespace Domain.DTOs;

public class PotGetAllDto
{
    public ICollection<Pot> Pots { get; set; }
    public string Message { get; set; }
    public bool Success { get; set; }
}