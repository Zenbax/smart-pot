﻿namespace ClassLibrary.Auth;

public static class AuthorizationPolicies
{
    
}